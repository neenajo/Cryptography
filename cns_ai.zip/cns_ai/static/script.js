async function hashText() {
    let text = document.getElementById("hashInput").value;
    let response = await fetch("/hash_text", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: text })
    });
    let data = await response.json();
    document.getElementById("hashOutput").innerText = data.hashed_text;
}

async function encryptText() {
    let text = document.getElementById("encryptInput").value;
    try {
        let response = await fetch("/encrypt_text", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ text: text })
        });

        if (!response.ok) throw new Error("Encryption failed");
        let data = await response.json();
        document.getElementById("encryptOutput").innerText = data.encrypted_text;
    } catch (error) {
        document.getElementById("encryptOutput").innerText = "Error: " + error.message;
    }
}
fetch('/decrypt', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
        ciphertext: encryptedData, 
        password: "your_secret_password"
    })
})
.then(response => response.json())
.then(data => console.log(data));
